﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
namespace GridPdf
{
    public partial class _Default : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            string[] headers = { "name", "phone", "email", };
            // a table with three columns
            PdfPTable table = new PdfPTable(headers.Length);
            // the cell object
            PdfPCell cell;

            for (int i = 0; i < headers.Length; i++)
            {
                string cellText = headers[i];
                cell = new PdfPCell(new Phrase(cellText));
                cell.BackgroundColor = new iTextSharp.text.BaseColor(System.Drawing.Color.Aqua);
                table.AddCell(cell);
            }
            string myConnectionString = "Server=localhost; Database=blog; Uid=root; Pwd=";
            
            MySqlConnection conn = null;

            try
            {
                conn = new MySqlConnection(myConnectionString);
                conn.Open();

                string stm = "SELECT name,phone,email FROM contact";
                MySqlDataAdapter da1 = new MySqlDataAdapter(stm, conn);

                DataSet ds1 = new DataSet();

                da1.Fill(ds1, "contact");
                DataTable dt = ds1.Tables["contact"];


                foreach (DataRow row in dt.Rows)
                {
                    foreach (DataColumn col in dt.Columns)
                    {

                        Console.WriteLine(row[col]);
                        string cellText = row[col].ToString();
                        cell = new PdfPCell(new Phrase(cellText));
                        table.AddCell(cell);
                    }

                    Console.WriteLine("".PadLeft(20, '='));
                }

            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());

            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }

            }

            //Create the PDF Document
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            pdfDoc.Add(table);
            pdfDoc.Close();
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;" +
                                           "filename=GridViewExport.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(pdfDoc);
            Response.End();



        }
    }
}

<?php
	//chama o arquivo de conexão com o bd
	include("conectar.php");

	$info = $_POST['contatos'];

	$data = json_decode(stripslashes($info));

	$nome = $data->name;
	$email = $data->email;
	$phone = $data->phone;
	$id = $data->id;

	//consulta sql
	$query = sprintf("UPDATE contact SET name = '%s', email = '%s', phone = '%s' WHERE id=%d",
		mysqli_real_escape_string($mysqli,$nome),
		mysqli_real_escape_string($mysqli,$email),
		mysqli_real_escape_string($mysqli,$phone),
		mysqli_real_escape_string($mysqli,$id));

	$rs = mysqli_query($mysqli,$query);

	echo json_encode(array(
		"success" => mysql_errno() == 0,
		"contatos" => array(
			"id" => $id,
			"name" => $nome,
			"email" => $email,
			"phone" => $phone
		)
	));
?>